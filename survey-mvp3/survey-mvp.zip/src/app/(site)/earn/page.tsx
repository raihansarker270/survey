import { getSessionFromCookie } from "@/src/lib/auth";

export default function EarnPage() {
  const session = getSessionFromCookie();
  const base = process.env.OFFERWALL_BASE_URL || "https://example-offerwall.com/wall";
  const uidParam = session?.userId ? `uid=${encodeURIComponent(session.userId)}` : "";
  const url = uidParam ? `${base}${base.includes("?") ? "&" : "?"}${uidParam}` : base;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Earn Surveys</h1>
      <div className="text-gray-300 text-sm">
        Complete surveys below. When a survey is marked as completed by the provider, your balance will update automatically.
      </div>
      <div className="card">
        <iframe
          src={url}
          className="w-full h-[70vh] rounded-xl border border-gray-800"
        />
      </div>
      <div className="text-xs text-gray-400">
        Note: If nothing loads, ensure you configured <code>OFFERWALL_BASE_URL</code> in your environment and whitelisted your domain in the provider dashboard.
      </div>
    </div>
  );
}
