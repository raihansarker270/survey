import { prisma } from "@/src/lib/prisma";
import { getSessionFromCookie } from "@/src/lib/auth";
import Link from "next/link";

async function getPending() {
  return prisma.withdrawal.findMany({
    where: { status: "pending" },
    orderBy: { createdAt: "asc" },
    include: { user: true },
  });
}

function isAdminEmail(email?: string | null) {
  const admin = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  return !!email && admin && email.toLowerCase().trim() === admin;
}

export default async function AdminWithdrawalsPage() {
  const session = getSessionFromCookie();
  if (!isAdminEmail(session?.email)) {
    return (
      <div className="card">
        <div className="text-sm text-gray-300">
          403 — Admin only. Please sign in with the admin email.
        </div>
        <div className="mt-3"><Link className="link" href="/">Go home</Link></div>
      </div>
    );
  }

  const rows = await getPending();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Admin · Pending Withdrawals</h1>

      {rows.length === 0 ? (
        <div className="card text-sm text-gray-300">No pending withdrawals.</div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-gray-400">
              <tr>
                <th className="py-2">Date</th>
                <th>User</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Details</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(w => {
                const details = (() => {
                  try { return JSON.parse(w.detailsJson)?.details ?? ""; }
                  catch { return w.detailsJson; }
                })();
                return (
                  <tr key={w.id} className="border-t border-gray-800">
                    <td className="py-2">{new Date(w.createdAt).toLocaleString()}</td>
                    <td className="text-gray-300">{w.user.email}</td>
                    <td>{w.amountPoints} pts</td>
                    <td>{w.method}</td>
                    <td className="text-gray-400 truncate max-w-[240px]">{details}</td>
                    <td className="space-x-2">
                      <form action="/api/admin/withdrawals/approve" method="POST" className="inline">
                        <input type="hidden" name="id" value={w.id} />
                        <button className="btn">Approve</button>
                      </form>
                      <form action="/api/admin/withdrawals/reject" method="POST" className="inline">
                        <input type="hidden" name="id" value={w.id} />
                        <button className="btn" style={{background:"#ef4444", color:"white"}}>Reject & Refund</button>
                      </form>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="text-xs text-gray-400">
        Approve = শুধু status পরিবর্তন। Reject = status পরিবর্তন + ইউজারের ওয়ালেটে **সমান পয়েন্ট রিফান্ড** (reversal)।
      </div>
    </div>
  );
}
