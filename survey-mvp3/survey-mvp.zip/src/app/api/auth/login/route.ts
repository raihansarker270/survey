import { prisma } from "@/src/lib/prisma";
import { NextResponse } from "next/server";
import { signSession, setSessionCookie } from "@/src/lib/auth";

export async function POST(req: Request) {
  try {
    const { email } = await req.json();
    if (!email || typeof email !== "string") {
      return NextResponse.json({ message: "Email required" }, { status: 400 });
    }
    const normalized = email.trim().toLowerCase();
    let user = await prisma.user.findUnique({ where: { email: normalized } });
    if (!user) {
      user = await prisma.user.create({
        data: { email: normalized, country: "US" } // set country later via Geo/IP
      });
    }
    const token = signSession({ userId: user.id, email: user.email });
    setSessionCookie(token);
    return NextResponse.json({ message: "Logged in" });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ message: "Login failed" }, { status: 500 });
  }
}
