import { NextResponse } from "next/server";
import { getSessionFromCookie } from "@/src/lib/auth";
import { prisma } from "@/src/lib/prisma";

function isAdmin(email?: string | null) {
  const a = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  return !!email && a && email.toLowerCase().trim() === a;
}

export async function POST(req: Request) {
  const s = getSessionFromCookie();
  if (!isAdmin(s?.email)) return NextResponse.json({ ok:false, error:"forbidden" }, { status: 403 });

  const form = await req.formData();
  const id = String(form.get("id") || "");
  if (!id) return NextResponse.json({ ok:false, error:"missing id" }, { status: 400 });

  const w = await prisma.withdrawal.findUnique({ where: { id } });
  if (!w) return NextResponse.json({ ok:false, error:"not found" }, { status: 404 });
  if (w.status !== "pending") {
    return NextResponse.redirect(new URL("/admin/withdrawals", process.env.SITE_URL), { status: 302 });
  }

  await prisma.withdrawal.update({ where: { id }, data: { status: "approved" } });

  return NextResponse.redirect(new URL("/admin/withdrawals", process.env.SITE_URL), { status: 302 });
}
